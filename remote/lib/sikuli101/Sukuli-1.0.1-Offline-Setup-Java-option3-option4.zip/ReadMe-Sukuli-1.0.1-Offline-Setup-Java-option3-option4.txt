ReadMe-Sukuli-1.0.1-Offline-Setup-Java-option3-option4
======================================================

After you downloaded the latest version of sikuli-setup-jar:

1. you have downloaded this package, to setup the IDE package offline

2. you have put the unzipped stuff
  -- 1.0.1-3.jar
  
into a folder named Downloads, that you created 
in the folder containing sikuli-setup.jar 

Now run setup again and carefully read what it is saying.

Setup will detect the local versions of the wanted packages and
use them instead of downloading them.

Do not try to use the downloaded stuff as is - it has to be
processed by setup, to be useable.

If you do it even so, be sure to get weird errors ;-)


  