ReadMe-Sukuli-1.0.1-Offline-Setup-TessData-option5
==================================================

After you downloaded the latest version of sikuli-setup-jar:

1. you have downloaded this package, to setup the IDE package offline

2. you have put the unzipped stuff
  -- 1.0.1-5.jar
  
into a folder named Downloads, that you created 
in the folder containing sikuli-setup.jar 

Now run setup again and carefully read what it is saying.

Setup will detect the local versions of the wanted packages and
use them instead of downloading them.

This package must be available, if you want to select any of
the options 1 .. 4 on setup together with option 5.
  